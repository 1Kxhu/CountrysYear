package kxhu.codes;

import kxhu.codes.Rok.Language;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Panstwa extends JavaPlugin implements Listener {

    public static Language currentLanguage = Language.EN_UK;

    @Override
    public void onEnable() {
        getLogger().info("started!");
        getServer().getPluginManager().registerEvents(this, this);

        String languageString = "EN-UK";

        if (Files.exists(Paths.get("settings.txt")))
        {
            try {
                languageString = new String(Files.readAllBytes(Paths.get("settings.txt")));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            try {
                Files.write(Paths.get("settings.txt"), languageString.getBytes());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        Language language = Language.EN_UK;
        switch (languageString) {
            case "PL-PL":
                language = Language.PL_PL;
                break;
            case "EN-UK":
                language = Language.EN_UK;
                break;
            default:
        }

        currentLanguage = language;

        Rok rok1 = new Rok();
        rok1.setLanguage(language);
        this.getCommand("rok").setExecutor(rok1);
        getCommand("rok").setTabCompleter(new RokTabCompleter());

        this.getCommand("orient").setExecutor(new Orient());
        getCommand("orient").setTabCompleter(new OrientTabCompleter());

        this.getCommand("language").setExecutor(new LanguageSwitcher());
        getCommand("language").setTabCompleter(new LangSwitcherTabCompleter());
    }
    @Override
    public void onDisable() {
        getLogger().info("onDisable is called!");
    }


    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        String year = "null";
        try {
            year = new String(Files.readAllBytes(Paths.get("year.txt")));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        if (!year.equals("null"))
        {
            event.getPlayer().sendMessage("Witaj, §7" + event.getPlayer().getName() + "§r! Na serwerze panuje rok: §a" + year);
        }
    }
}