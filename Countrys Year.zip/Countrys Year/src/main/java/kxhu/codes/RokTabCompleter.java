package kxhu.codes;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RokTabCompleter implements TabCompleter {

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            if (Panstwa.currentLanguage == Rok.Language.PL_PL)
            {
                return Arrays.asList("ustaw", "wyswietl", "dodaj");
            }
            else if (Panstwa.currentLanguage == Rok.Language.EN_UK)
            {
                return Arrays.asList("set", "view", "add");
            }
        }
        return Collections.emptyList();
    }
}
