package kxhu.codes;

public class Vector3 {
    public Vector3(int i, int i1, int i2) {
    }
}
