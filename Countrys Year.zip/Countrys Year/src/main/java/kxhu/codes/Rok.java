package kxhu.codes;

import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Rok implements CommandExecutor {

    enum Language {
        PL_PL, EN_UK
    }

    private Language language = Language.EN_UK;

    public void setLanguage(Language language) {
        this.language = language;

    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
       language = Panstwa.currentLanguage;
        if (label.equalsIgnoreCase("rok") || label.equalsIgnoreCase("panstwaplugin") || label.equalsIgnoreCase("year")) {
            if (args.length < 1) {
                sendMessage(sender, "Usage: /year <set/view/add> [year]", "Użycie: /rok <ustaw/wyświetl/dodaj> [rok]");
                return true;
            }

            if (!(sender instanceof Player) && !sender.getName().equals("CONSOLE")) {
                return true;
            }

            String subCommand = args[0].toLowerCase();

            String oldYear = "null";
            if (new File("year.txt").exists()) {
                try {
                    oldYear = new String(Files.readAllBytes(Paths.get("year.txt")));
                } catch (IOException ignored) {
                }
            }

            if (subCommand.equals("set") || subCommand.equals("ustaw")) {
                if (args.length < 2) {
                    sendMessage(sender, "Usage: /year set <year>", "Użycie: /rok ustaw <rok>");
                    return true;
                }

                String year = args[1];

                try {
                    Integer.parseInt(year);
                } catch (NumberFormatException e) {
                    sendMessage(sender, "§cYou did not provide a number, check the command argument.",
                            "§cNie podano liczby, sprawdź argument komendy.");
                    return true;
                }

                try {
                    Files.write(Paths.get("year.txt"), year.getBytes());
                    sendMessage(sender, "Year set: §a" + year + " §7(year before change: §f" + oldYear + "§7)",
                            "Ustawiono rok: §a" + year + " §7(rok przed zmianą: §f" + oldYear + "§7)");
                    Bukkit.getServer().broadcastMessage(getBroadcastMessage(sender.getName(), year));
                    for (Player player : Bukkit.getOnlinePlayers()) {
                        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1, 1);
                        player.sendTitle(getNewYearTitle(year), "Set by: §7" + sender.getName());
                    }
                } catch (IOException e) {
                    sendMessage(sender, "§cAn error occurred while writing the year to the file (error in console)",
                            "§cWystąpił błąd podczas pisania roku do pliku (błąd w konsoli)");
                    e.printStackTrace();
                }
            } else if (subCommand.equals("set") || subCommand.equals("wyświetl")) {
                File yearFile = new File("year.txt");

                if (!yearFile.exists()) {
                    sendMessage(sender, "§cYear is not set on this server yet.",
                            "§cRok jeszcze nie jest ustawiony na tym serwerze.");
                    return true;
                }

                try {
                    String yearContent = new String(Files.readAllBytes(Paths.get("year.txt")));
                    sendMessage(sender, "It is year: §a" + yearContent, "Jest rok: §a" + yearContent);
                } catch (IOException e) {
                    sendMessage(sender, "§cAn error occurred while reading the year from the file (error in console)",
                            "§cWystąpił błąd podczas czytania roku z pliku (błąd w konsoli)");
                    e.printStackTrace();
                }
            } else {
                sendMessage(sender, "Usage: /year <set/view/add> [year]", "Użycie: /rok <ustaw/wyświetl/dodaj> [rok]");
            }

            return true;
        }

        return false;
    }

    private void sendMessage(CommandSender sender, String englishMessage, String polishMessage) {
        switch (language) {
            case PL_PL:
                sender.sendMessage(polishMessage);
                break;
            case EN_UK:
                sender.sendMessage(englishMessage);
                break;
        }
    }

    private String getBroadcastMessage(String playerName, String year) {
        switch (language) {
            case PL_PL:
                return "§c[Globalne] §r" + playerName + " ustawił rok na: §a" + year;
            case EN_UK:
                return "§c[Global] §r" + playerName + " set the year to: §a" + year;
            default:
                return "";
        }
    }

    private String getNewYearTitle(String year) {
        switch (language) {
            case PL_PL:
                return "Nowy rok: §a" + year;
            case EN_UK:
                return "New year: §a" + year;
            default:
                return "";
        }
    }
}
