package kxhu.codes;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.stream.Collectors;

public class LangSwitcherTabCompleter implements TabCompleter {

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return EnumSet.allOf(Rok.Language.class)
                    .stream()
                    .map(Enum::name)
                    .collect(Collectors.toList());
        }
        return Collections.emptyList();
    }

}
