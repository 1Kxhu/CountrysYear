package kxhu.codes;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class OrientTabCompleter implements TabCompleter {

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            if (Panstwa.currentLanguage == Rok.Language.PL_PL)
            {
                return Arrays.asList("polnoc", "polodnie", "wschod", "zachod");
            } else if (Panstwa.currentLanguage == Rok.Language.EN_UK)
            {
                return Arrays.asList("north", "south", "east", "west");
            }
        }
        return Collections.emptyList();
    }
}
