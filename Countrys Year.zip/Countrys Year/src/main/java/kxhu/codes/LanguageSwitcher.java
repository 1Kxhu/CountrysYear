package kxhu.codes;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class LanguageSwitcher implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("language")) {
            if (args.length < 1) {
                return true;
            }

            if (!(sender instanceof Player) && !sender.getName().equals("CONSOLE")) {
                return true;
            }

            String languageString = args[0].toUpperCase();

            Rok.Language language = null;
            switch (languageString) {
                case "PL_PL":
                    language = Rok.Language.PL_PL;
                    break;
                case "EN_UK":
                    language = Rok.Language.EN_UK;
                    break;
                default:
                    break;
            }

            if (language == null) {
                sender.sendMessage("Argument isn't in the list, try again.");
                return false;
            }

            Panstwa.currentLanguage = language;

            switch (language)
            {
                case EN_UK ->       sender.sendMessage("Language set to: §a" + language);
                case PL_PL ->       sender.sendMessage("Ustawiono język na: §a" + language);
            }

            try {
                Files.write(Paths.get("settings.txt"), languageString.getBytes());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            return true;
        }
        return false;
    }
}
