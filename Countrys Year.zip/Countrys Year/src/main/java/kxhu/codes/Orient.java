package kxhu.codes;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import static kxhu.codes.Panstwa.currentLanguage;

public class Orient implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (label.equalsIgnoreCase("orient") || label.equalsIgnoreCase("face") || label.equalsIgnoreCase("patrz")) {
            if (!(sender instanceof Player player)) {
                if (currentLanguage == Rok.Language.PL_PL) {
                    sender.sendMessage("To może być użyte tylko przez graczy.");
                }
                else if (currentLanguage == Rok.Language.EN_UK) {
                    sender.sendMessage("This command can only be used by players.");
                }
                return true;
            }

            if (args.length < 1) {
                if (currentLanguage == Rok.Language.PL_PL) {
                    sender.sendMessage("To może być użyte tylko przez graczy.");
                }
                else if (currentLanguage == Rok.Language.EN_UK) {
                    sender.sendMessage("This command can only be used by players.");
                }
                return true;
            }

            String direction = args[0].toLowerCase();

            switch (direction) {
                case "wschod":
                    Location l = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), -90, 0);
                    player.teleport(l);
                    return true;
                case "zachod":
                    Location l1 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), -270, 0);
                    player.teleport(l1);
                    return true;
                case "polnoc":
                    Location l2 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), 180, 0);
                    player.teleport(l2);
                    return true;
                case "polodnie":
                    Location l3 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), 0, 0);
                    player.teleport(l3);
                    return true;
                case "east":
                    Location l4 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), -90, 0);
                    player.teleport(l4);
                    return true;
                case "west":
                    Location l5 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), -270, 0);
                    player.teleport(l5);
                    return true;
                case "north":
                    Location l6 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), 180, 0);
                    player.teleport(l6);
                    return true;
                case "south":
                    Location l7 = new Location(player.getWorld(), player.getLocation().getX(), player.getLocation().getY(), player.getLocation().getZ(), 0, 0);
                    player.teleport(l7);
                    return true;
                default:
                    if (currentLanguage == Rok.Language.PL_PL) {
                        sender.sendMessage("Niewłaściwy argument, użyj 'poludnie', 'polnoc', 'wschod', 'zachod'");
                    }
                    else if (currentLanguage == Rok.Language.EN_UK) {
                        sender.sendMessage("Invalid argument, use 'south', 'north', 'east', 'west'");
                    }
                    return true;
            }
        }
        return false;
    }

}
